"""
mograph.v14.denoise — automatic broadcast voice cleanup (noise cancelling) for talking-head footage.

No knobs needed: it MEASURES the take and picks the strength itself.

  1  measure      noise floor (quietest 10 % of 50 ms windows) vs speech level → SNR
  2  rnnoise      neural speech denoiser (RNNoise, ffmpeg `arnndn`, models in mograph/models/rnnoise:
                  lq = voice vs general noise (default, best in QC listening test), bd, sh, cb, mp).
                  The dry/wet mix is chosen from the SNR (noisy take → 0.72, clean studio → 0.40) so clean
                  voices never get the "underwater" artefact.
  3  residual     OPTIONAL spectral gate (noisereduce) — off by default (QC: phasey on outdoor takes)
  4  polish       de-click, high-pass 90 Hz, mud cut (-2 dB @ 250 Hz), presence (+2.5 dB @ 4 kHz),
                  air (+2.5 dB shelf @ 9.5 kHz), light de-ess.  NO gate/expander (QC: pumping, eaten endings).
  5  report       before/after noise floor & SNR → <cache>/denoise_report.json

Use:   from mograph.v14.denoise import clean_voice ;  wav = clean_voice("media/raw.mp4")   (cached)
CLI:   python3 -m mograph.v14.denoise media/raw.mp4  [--model bd|sh|cb|lq|mp] [--strength auto|0..1]
Spec:  "audio": {"denoise": "auto"}   ("off" | "auto" | 0..1 strength | {"model": "sh", "strength": 0.8})
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys

import numpy as np

SR = 48000
MODELS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", "rnnoise")


def _read(path, sr=SR):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"],
                         capture_output=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def _write(path, x, sr=SR):
    import wave
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
        wf.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())


def _ff(x, af, sr=SR):
    p = subprocess.run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(sr), "-ac", "1", "-i", "-", "-af", af,
                        "-f", "f32le", "-ar", str(sr), "-ac", "1", "-"], input=x.astype(np.float32).tobytes(),
                       capture_output=True)
    if p.returncode != 0 or not p.stdout:
        raise RuntimeError(p.stderr.decode()[-400:])
    y = np.frombuffer(p.stdout, np.float32).copy()
    return y[:len(x)] if len(y) >= len(x) else np.pad(y, (0, len(x) - len(y)))


def measure(x, sr=SR):
    """Noise floor = RMS of the quietest 10 % of 50 ms windows; speech = loudest 30 %."""
    n = int(0.05 * sr)
    k = len(x) // n
    if k < 10:
        return {"noise_db": -90.0, "speech_db": -20.0, "snr_db": 70.0}
    r = np.sqrt((x[:k * n].reshape(k, n) ** 2).mean(1) + 1e-12)
    r = np.sort(r)
    nz = r[: max(1, k // 10)].mean()
    sp = r[-max(1, int(k * 0.3)):].mean()
    db = lambda v: float(20 * np.log10(v + 1e-12))
    return {"noise_db": round(db(nz), 1), "speech_db": round(db(sp), 1), "snr_db": round(db(sp) - db(nz), 1)}


def clean(x, sr=SR, model="lq", strength="auto", residual=False, log=print):
    """QC-tuned (listening tests on an outdoor fountain take): a FULL-wet neural pass + spectral gate + expander
    sounded metallic / gated / swallowed word endings.  The transparent recipe is: partial-wet RNNoise (keeps a
    little natural ambience so pauses are not a 'vacuum'), NO gate, then restore presence & air."""
    m0 = measure(x, sr)
    snr = m0["snr_db"]
    if strength == "auto":
        # noisy (SNR ≤ 12 dB) → 0.72 ; clean (≥ 35 dB) → 0.40  (QC: keep ~25 % natural ambience)
        s = float(np.clip(0.72 - (snr - 12) / 23 * 0.32, 0.40, 0.72))
    else:
        s = float(strength)
    mpath = os.path.join(MODELS, f"{model}.rnnn")
    y = _ff(x, "adeclick=w=55:o=75,highpass=f=90")
    if os.path.exists(mpath) and s > 0:
        y = _ff(y, f"arnndn=m='{mpath}':mix={s:.2f}")
    else:
        log("[denoise] RNNoise model missing → afftdn fallback")
        y = _ff(y, f"afftdn=nr={6 + 12 * s:.0f}:nf=-50:tn=1")
    if residual:   # optional: residual stationary hiss (can sound phasey — off by default)
        try:
            import noisereduce as nr
            y = nr.reduce_noise(y=y, sr=sr, stationary=True, prop_decrease=0.3, n_fft=2048,
                                freq_mask_smooth_hz=500, time_mask_smooth_ms=100).astype(np.float32)
        except Exception as e:  # noqa: BLE001
            log(f"[denoise] residual stage skipped ({e.__class__.__name__})")
    polish = ("equalizer=f=250:t=q:w=1.0:g=-2,"        # mud
              "equalizer=f=4000:t=q:w=0.9:g=2.5,"      # presence (undo denoise dulling)
              "highshelf=f=8500:g=3,"                # air
              "deesser=i=0.25:m=0.5:f=0.5")
    y = _ff(y, polish)
    m1 = measure(y, sr)
    return y, {"before": m0, "after": m1, "model": model, "strength": round(s, 2)}


def clean_voice(src, model="lq", strength="auto", log=print, residual=False):
    """Cached: returns path of a 48 kHz mono cleaned WAV next to the media cache."""
    cdir = src + ".v14"
    os.makedirs(cdir, exist_ok=True)
    key = hashlib.md5(f"{os.path.getsize(src)}|{model}|{strength}|{residual}|v3".encode()).hexdigest()[:8]
    out = os.path.join(cdir, f"voice_clean_{key}.wav")
    if os.path.exists(out):
        return out
    x = _read(src)
    y, rep = clean(x, SR, model, strength, residual, log)
    _write(out, y)
    with open(os.path.join(cdir, "denoise_report.json"), "w") as f:
        json.dump(rep, f, indent=1)
    log(f"[denoise] {rep['before']} → {rep['after']}  (rnnoise {model}, mix {rep['strength']})")
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--model", default="lq")
    ap.add_argument("--strength", default="auto")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    st = a.strength if a.strength == "auto" else float(a.strength)
    p = clean_voice(a.src, a.model, st)
    if a.out:
        import shutil
        shutil.copy(p, a.out)
        p = a.out
    print(p)
    sys.exit(0)
