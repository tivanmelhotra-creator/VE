#!/usr/bin/env bash
# One-shot environment restore for mograph v14 (run after ANY sandbox reset):
#   bash /home/user/webapp/sdk/tools/setup_env.sh
set -e
cd "$(dirname "$0")/.."
pip install noisereduce -q pycairo uharfbuzz fonttools freetype-py mediapipe onnxruntime opencv-python numpy scipy pillow 2>&1 | tail -1 || true
(sudo apt-get install -y -q libegl1 libgles2 >/dev/null 2>&1) || true
M=mograph/models/modnet.onnx
if [ ! -s "$M" ]; then
  echo "[setup] downloading MODNet portrait matting model (25 MB, Apache-2.0)…"
  curl -sL -o "$M" "https://huggingface.co/Xenova/modnet/resolve/main/onnx/model.onnx" || true
fi
python3 -c "import cairo, uharfbuzz, cv2, onnxruntime, mediapipe; print('[setup] OK  cairo', cairo.version, '| cv2', cv2.__version__)"
